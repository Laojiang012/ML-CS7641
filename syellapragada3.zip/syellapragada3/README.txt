Uncomment the few line in main function to perfom analysis on second data set
