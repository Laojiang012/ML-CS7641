import os, re
import csv
import pandas as pd

def getBestParam(atIteration, type= 'CP GA-'):

    # output_filename = type+str(atIteration)
    # csv_file = open(output_filename, 'w')
    # fields = ['num_iterations', 'value', 'time']
    # writer = csv.DictWriter(csv_file, fieldnames=fields)
    # writer.writeheader()
    new_df = pd.DataFrame(columns=["Params", "Value"])
    for f in sorted(os.listdir('.')):
        if re.match(type, f):
            print f
            g = f
            l = len(type)
            g = g[l:-4]
            g = g.split("_")
            g = map(int, g)
            # print g
            df = pd.read_csv(f)

            temp = df.loc[df['num_iterations'] == atIteration]
            temp1 = pd.DataFrame([[g, float(temp["train_time"]), float(temp["test_time"])]],
                                 columns=["Params", "Train Time", "Test Time"])
            new_df = pd.concat([new_df, temp1])
            # writer.writerow()

    new_df.to_csv(str(atIteration)+"-"+type+"time.csv", index=False)

if __name__ == "__main__":
    getBestParam(6000, type='GA-')