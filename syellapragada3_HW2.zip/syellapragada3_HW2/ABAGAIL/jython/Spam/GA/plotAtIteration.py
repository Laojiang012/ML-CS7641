import pandas as pd
import matplotlib.pyplot as plt

def plotAtIteration(file, value=True, train=True):
    time = pd.read_csv(file)

    ax = time[("Train" if train else "Test") + (" Accuracy" if value else " Time")].plot(linewidth=3.0)
    # ax.set_ylim(ymin=min())
    # ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.075), ncol=5)
    ax.yaxis.grid()
    ax.set_ylim(ymin=0)
    x_ticks = time["Params"]
    # ax.set_xticklabels(labels=x_ticks ,rotation=(0), fontsize=8)
    #, va='bottom', ha='left'
    plt.ylabel("Fitness function value" if value else "Computation time")
    plt.xlabel("[Population size, To Mate, To Mutate]")

    plt.xticks(time.index.values, x_ticks, rotation=75, fontsize= 8)


    # plt.title("Knapsack - Time comparision for best parameters", fontsize=15)
    # plt.show()
    f = file.split(".")
    plt.savefig(f[0] + ("Train" if train else "Test") + ".png", dpi=500, bbox_inches='tight')

plotAtIteration("6000-GA-.csv", value=True, train=True)
