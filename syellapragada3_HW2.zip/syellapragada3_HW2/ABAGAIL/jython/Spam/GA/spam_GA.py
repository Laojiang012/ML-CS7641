"""
Implementation of randomized hill climbing, simulated annealing, and genetic algorithm to
find optimal weights to a neural network that is classifying abalone as having either fewer
or more than 15 rings.

Based on AbaloneTest.java by Hannah Lau
"""

from __future__ import with_statement

import os
import csv
import time
import sys

sys.path.append("../../../bin")

from func.nn.backprop import BackPropagationNetworkFactory
from shared import SumOfSquaresError, DataSet, Instance
from opt.example import NeuralNetworkOptimizationProblem

import opt.RandomizedHillClimbing as RandomizedHillClimbing
import opt.SimulatedAnnealing as SimulatedAnnealing
import opt.ga.StandardGeneticAlgorithm as StandardGeneticAlgorithm
from func.nn.activation import LogisticSigmoid

INPUT_TRAIN = os.path.join("..", "data", "spam-tst.csv")
INPUT_TEST = os.path.join("..", "data", "spam-trn.csv")

INPUT_LAYER = 57
HIDDEN_LAYER = 15
OUTPUT_LAYER = 1
# TRAINING_ITERATIONS = 1000


def initialize_instances():
    """Read the abalone.txt CSV data into a list of instances."""
    train_instances = []
    test_instances = []

    data_test = os.path.join("..", "..","..", "data", "spam-test.csv")
    data_train = os.path.join("..", "..", "..", "data", "spam-train.csv")

    # Read in the abalone.txt CSV file
    with open(data_train, "r") as sat_train:
        reader = csv.reader(sat_train)
        for row in reader:
            # print len(row)
            instance = Instance([float(value) for value in row[:-1]])
            instance.setLabel(Instance(int(row[-1])))
            train_instances.append(instance)

    with open(data_test, "r") as sat_test:
        reader = csv.reader(sat_test)
        for row in reader:
            instance = Instance([float(value) for value in row[:-1]])
            instance.setLabel(Instance(float(row[-1])))
            test_instances.append(instance)

    return train_instances, test_instances


def train(oa, network, oaName, instances, measure, TRAINING_ITERATIONS):
    """Train a given network on a set of instances.

    :param OptimizationAlgorithm oa:
    :param BackPropagationNetwork network:
    :param str oaName:
    :param list[Instance] instances:
    :param AbstractErrorMeasure measure:
    """
    print "\nError results for %s\n---------------------------" % (oaName,)

    for iteration in xrange(TRAINING_ITERATIONS):
        oa.train()

        error = 0.00
        for instance in instances:
            network.setInputValues(instance.getData())
            network.run()

            output = instance.getLabel()
            output_values = network.getOutputValues()
            example = Instance(output_values, Instance(output_values.get(0)))
            error += measure.value(output, example)

        print "%0.03f" % error


def test(network, instances):
    correct = 0
    incorrect = 0

    for instance in instances:
        network.setInputValues(instance.getData())
        network.run()

        predicted = instance.getLabel().getContinuous()
        actual = network.getOutputValues().get(0)

        if abs(predicted - actual) < 0.5:
            correct += 1
        else:
            incorrect += 1

    return correct / float(correct + incorrect)


def main():
    optalgs = ['RHC', 'GA', 'SA']

    OA = {
        'RHC': RandomizedHillClimbing,
        'GA': StandardGeneticAlgorithm,
        'SA': SimulatedAnnealing
    }

    params = {
        'RHC': [[]],
        'GA': [
            # [10, 5, 2], [10, 5, 7], [10, 7, 2], [10, 7, 7],
            # [20, 10, 5], [20, 10, 8], [20, 15, 5], [20, 15, 8],
            # [50, 25, 10], [50, 25, 15],
            [50, 40, 10], [50, 40, 15]
            # ,
            # [100, 50, 10], [100, 50, 20],
            # [100, 80, 10], [100, 80, 20],
            # [200, 100, 20], [200, 100, 50],
            # [200, 150, 20], [200, 150, 50],
            # [500, 350, 50], [500, 350, 100],
            # [500, 450, 50], [500, 450, 100]
        ],
        'SA': [
        [1e11, 0.15], [1e11, 0.25], [1e11, 0.35], [1e11, 0.45], [1e11, 0.55],
        [1e11, 0.65], [1e11, 0.75], [1e11, 0.85], [1e11, 0.95],
        [1e5, 0.15], [1e5, 0.25], [1e5, 0.35], [1e5, 0.45], [1e5, 0.55],
        [1e5, 0.65], [1e5, 0.75], [1e5, 0.85], [1e5, 0.95]
        ]
    }

    identifier = {
        'RHC': lambda p: 'noparams',
        'GA': lambda p: '_'.join([str(v) for v in p]),
        'SA': lambda p: (str(p[0]) + "-"+(str(p[1]))).replace('.', '_')
    }

    iterations = range(1000, 10001, 1000)

    train_instances, test_instances = initialize_instances()

    data_set = DataSet(train_instances)
    factory = BackPropagationNetworkFactory()
    measure = SumOfSquaresError()

    optalg = "GA"
    for param in params[optalg]:
        output_filename = '%s-%s.csv' % (optalg, identifier[optalg](param))
        csv_file = open(output_filename, 'w')
        fields = ['num_iterations', 'train_accuracy', 'test_accuracy', 'train_time', 'test_time']
        writer = csv.DictWriter(csv_file, fieldnames=fields)
        writer.writeheader()

        for num_iterations in iterations:
            network = factory.createClassificationNetwork(
                [INPUT_LAYER, HIDDEN_LAYER, OUTPUT_LAYER], LogisticSigmoid())
            nnop = NeuralNetworkOptimizationProblem(data_set, network, measure)

            oa = OA[optalg](*(param + [nnop]))

            start = time.time()
            train(oa, network, optalg, train_instances, measure, num_iterations)
            end = time.time()
            train_time = end - start

            optimal_instance = oa.getOptimal()
            network.setWeights(optimal_instance.getData())
            train_accuracy = test(network, train_instances)

            start = time.time()
            test_accuracy = test(network, test_instances)
            end = time.time()
            test_time = end - start

            results = {
                'num_iterations': num_iterations,
                'train_accuracy': train_accuracy,
                'test_accuracy': test_accuracy,
                'train_time': train_time,
                'test_time': test_time
            }

            print optalg, param, results
            writer.writerow(results)

        csv_file.close()
        print '------'

    print '***** ***** ***** ***** *****'



if __name__ == "__main__":
    main()

