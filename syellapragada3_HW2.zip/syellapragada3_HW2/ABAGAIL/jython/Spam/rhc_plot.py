import os, re
import csv
import pandas as pd
import matplotlib.pyplot as plt

def plotGraph(ga, sa, train=True, value=True):
    # ga_type = "GA"
    # ga = pd.read_csv(ga_type+"/"+"GA-"+"_".join(ga)+".csv")
    # ga_df = ga[("train" if train else "test") + ("_accuracy" if value else "_time")]
    # # plt.show()
    # ax = ga_df.plot(label="GA", linewidth=3.0)
    # # plt.show()
    #
    # sa_type = "SA"
    # sa_df = pd.read_csv(sa_type + "/" + "SA-" + "-".join(sa)+".csv")[("train" if train else "test") + ("_accuracy" if value else "_time")]
    # ax = sa_df.plot(ax=ax, label="SA", linewidth=3.0)
    rhc = pd.read_csv("RHC-noparams.csv")
    rhc_df = rhc[("train" if train else "test") + ("_accuracy" if value else "_time")]
    ax = rhc_df.plot(label="RHC", linewidth=3.0)
    ax.set_ylim(ymin=0)
    ax.legend(loc='upper left', bbox_to_anchor=(1, 1))
    ax.yaxis.grid()

    x_ticks = map(str, rhc["num_iterations"])
    # ax.set_xticks(x_ticks)
    plt.ylabel(("Train" if train else "Test") + (" Accuracy" if value else " Time"))
    plt.xlabel("Number of Iterations")
    plt.xticks(rhc_df.index.values, x_ticks, rotation=75, fontsize= 8)
    plt.title("Spam Dataset")
    # plt.show()
    plt.savefig(("value" if value else "time")+"plot"+("-Train" if train else "-Test")+".png", dpi=500, bbox_inches='tight')

if __name__ == "__main__":
    plotGraph(ga=["200", "100", "20"], sa=["1e+11", "0_25"], train=False, value=False)