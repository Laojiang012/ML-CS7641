from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import cross_val_score
import os
import sys
sys.path.append("../../../bin")

def neuralNet(statDataX, statDataY, hidden_layers):
    mlp = MLPClassifier(hidden_layer_sizes=hidden_layers, activation="logistic")
    scores = cross_val_score(mlp, statDataX, statDataY, cv=10)
    # score = accuracy_score(statDataY, prediction)
    print("Cross Validation Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))
    return scores.mean()

def neuralNetTest(statDataX, statDataY, testX, testY, hidden_layers):
    mlp = MLPClassifier(hidden_layer_sizes=hidden_layers, learning_rate_init=0.01, activation="logistic")
    mlp.fit(statDataX, statDataY)
    prediction = mlp.predict(testX)
    score = accuracy_score(testY, prediction)
    print ("Test Accuracy: %0.2f" % score)
    return score

if __name__ == "__main__":
    # Loading data set
    print 'reading data'
    INPUT_TRAIN = os.path.join("..","..", "data", "spam-test.csv")
    INPUT_TEST = os.path.join("..","..", "data", "spam-train.csv")
    statData = pd.read_csv(INPUT_TRAIN, header=None, delimiter=",")
    testData = pd.read_csv(INPUT_TEST, header=None, delimiter=",")

    X = statData.iloc[:, :-1]
    Y = statData.iloc[:, -1]
    testX = testData.iloc[:, :-1]
    testY = testData.iloc[:, -1]

    testAcc = []

    print "\nNN\n"
    acc = neuralNet(X, Y, hidden_layers=(15))
    testAcc = neuralNetTest(X, Y, testX, testY, hidden_layers=(15))
