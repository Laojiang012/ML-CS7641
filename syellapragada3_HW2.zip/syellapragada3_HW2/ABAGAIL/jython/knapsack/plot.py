import os, re
import csv
import pandas as pd
import matplotlib.pyplot as plt

def plotGraph(type, ga, mimic, sa):
    ga_type = type+"-"+"GA"
    ga = pd.read_csv(ga_type+"/"+type+" GA-"+"_".join(ga)+".csv")
    ga_df = ga["value"]
    # plt.show()
    ax = ga_df.plot(label="GA", linewidth=3.0)
    # plt.show()
    m_type = type + "-" + "MIMIC"
    m_df = pd.read_csv(m_type + "/" + type + " MIMIC-" + "_".join(mimic)+".csv")["value"]
    ax = m_df.plot(ax=ax, label="MIMIC", linewidth=3.0)
    sa_type = type + "-" + "SA"
    sa_df = pd.read_csv(sa_type + "/" + type + " SA-" + "-".join(sa)+".csv")["value"]
    ax = sa_df.plot(ax=ax, label="SA", linewidth=3.0)
    rhc_df = pd.read_csv(type + " RHC-noparams.csv")[ "value"]
    ax = rhc_df.plot(ax=ax, label="RHC", linewidth=3.0)
    ax.set_ylim(ymin=0)
    ax.legend(loc='upper left', bbox_to_anchor=(1, 1))
    ax.yaxis.grid()

    x_ticks = map(str, ga["num_iterations"])
    # ax.set_xticks(x_ticks)
    plt.ylabel("Fitness function value")
    plt.xlabel("Number of Iterations")
    plt.xticks(rhc_df.index.values, x_ticks)
    plt.title("Knapsack")
    # plt.show()
    plt.savefig("valueplot.png", dpi=500, bbox_inches='tight')

if __name__ == "__main__":
    plotGraph("Knapsack", ["500", "450", "100"], ["160", "90"], ['100000_0', '0_95'])